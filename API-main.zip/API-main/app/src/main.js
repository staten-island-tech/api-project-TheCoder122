const appState={
  baseUrl:"https://v2.jokeapi.dev/joke/Programming,Miscellaneous,Pun,Spooky,Christmas",
  blacklist:"nsfw,religious,political,racist,sexist,explicit",
  amount:3
};
const jokeOutput=document.getElementById("joke-output");
const form=document.getElementById("search-form");
const input=document.getElementById("search-input");
const randomBtn=document.getElementById("random-btn");
const delay=(ms)=>new Promise(resolve=>setTimeout(resolve,ms));
async function fetchJokes(url){
  try{
    const response=await fetch(url,{cache:"no-store"});
    if(!response.ok) throw new Error("Network error");
    const data=await response.json();
    if(data.error) throw new Error("API error");
    return data.jokes??[data];
  }catch(error){
    jokeOutput.textContent="Failed to load jokes.";
    console.error(error);
    throw error;
  }
}
function renderJokes(jokes){
  jokeOutput.textContent="";
  jokes.forEach(joke=>{
    const html=joke.type==="single"
      ?`<p>${joke.joke}</p>`
      :`<p>${joke.setup} — ${joke.delivery}</p>`;
    jokeOutput.insertAdjacentHTML("beforeend",html);
  });
}
async function loadRandomJokes(){
  jokeOutput.textContent="Loading...";
  await delay(800);
  const url=`${appState.baseUrl}?amount=${appState.amount}&blacklistFlags=${appState.blacklist}&t=${Date.now()}`;
  const jokes=await fetchJokes(url);
  renderJokes(jokes);
}
form.addEventListener("submit",async(e)=>{
  e.preventDefault();
  const query=input.value.trim();
  if(!query){
    alert("Search field cannot be empty");
    return;
  }
  jokeOutput.textContent="Searching...";
  await delay(800);
  const url=`${appState.baseUrl}?contains=${encodeURIComponent(query)}&amount=${appState.amount}&blacklistFlags=${appState.blacklist}&t=${Date.now()}`;
  const jokes=await fetchJokes(url);
  renderJokes(jokes);
  form.reset();
});
randomBtn.addEventListener("click",loadRandomJokes);
loadRandomJokes();
